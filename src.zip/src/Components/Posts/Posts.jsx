import Post from "../Post/Post.jsx"
import './Posts.css'
import React from "react"

export default function Posts() {
  return (
    <div className='Posts'>
        <Post/>
        <Post/>
        <Post/>
        <Post/>
        <Post/>
        <Post/>
    </div>
  )
}
